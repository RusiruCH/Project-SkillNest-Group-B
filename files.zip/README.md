# SkillNest

Open course-ware and technical skill development platform — CA1 group project for **SWT22022 (Internet Application Development)**, South Eastern University of Sri Lanka.

## Overview

SkillNest gives learners one place to browse courses, work through learning materials, practice programming in a built-in Code Playground, take on Hackathon Challenges, sit quizzes, and ask questions in a Forum & Q&A section. Instructors apply for access and submit courses for review; an administrator approves instructors and courses before learners ever see them.

## Tech stack

- **Frontend:** React (Vite), React Router, Axios
- **Backend:** Node.js, Express.js
- **Database:** MongoDB (via Mongoose)
- **Auth:** JWT + bcrypt, role-based access control (`admin` / `instructor` / `learner`)

## Team — Group B

| Member | Module |
|---|---|
| L.M.R.C. Bandara | Course & Learning Material Management |
| W.M.A.P.S. Abeyrathne | Instructor & Course Approval Management |
| B.S.D.P. Wickramasingha | Code Playground |
| H.A.K. Madushan | Hackathon Challenge Management |
| R.D.T.S. Karunarathna | Quiz & Assessment Management |
| G.K.M.K.J. Kaushalya | Forum & Q&A |

## Project structure

```
skillnest/
├── client/                  # React app (Vite)
│   └── src/
│       ├── api/             # axios instance
│       ├── context/         # AuthContext
│       ├── components/      # shared UI (Navbar, ProtectedRoute)
│       └── pages/           # one folder per module
│           ├── auth/
│           ├── courses/         # Member 1
│           ├── approval/        # Member 2
│           ├── playground/      # Member 3
│           ├── hackathons/      # Member 4
│           ├── quizzes/         # Member 5
│           └── forum/           # Member 6
│
└── server/                  # Express API
    └── src/
        ├── config/db.js     # Mongoose connection
        ├── models/          # Mongoose schemas
        ├── middleware/      # auth.middleware.js (JWT + role guard)
        ├── controllers/     # one per module
        ├── routes/          # one per module
        └── index.js         # app entry point
```

Each module's route/controller pair is a placeholder — build your module's logic inside your own files so merges stay clean.

## Getting started

### Prerequisites
- Node.js 18+
- A MongoDB connection — either running locally or a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

### 1. Clone & install

```bash
git clone <your-repo-url>
cd skillnest

cd client && npm install
cd ../server && npm install
```

### 2. Configure environment variables

```bash
cd server
cp .env.example .env
# then fill in MONGO_URI and JWT_SECRET
```

### 3. Run in development

```bash
# terminal 1 — API
cd server && npm run dev

# terminal 2 — client
cd client && npm run dev
```

- Client: http://localhost:5173
- API: http://localhost:5000 (health check at `/api/health`)

The Vite dev server proxies `/api` requests to the Express server, so the client can just call `axiosClient.get('/courses')` without hardcoding a host.

## Branching

- `main` is protected — no direct pushes, PRs with at least one approval required.
- One feature branch per module:
  `feature/course-management`, `feature/approval-workflow`, `feature/code-playground`, `feature/hackathon-challenges`, `feature/quiz-assessment`, `feature/forum-qa`.

## License

No license — coursework project (all rights reserved) unless the team decides otherwise.
